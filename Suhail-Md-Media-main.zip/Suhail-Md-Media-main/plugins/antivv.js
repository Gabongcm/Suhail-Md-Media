/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail Tech Info
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.2 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 11/18/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/



const _0x231187=_0x444b;(function(_0x38d486,_0x34a878){const _0x11a61e=_0x444b,_0x12034a=_0x38d486();while(!![]){try{const _0x3bf853=-parseInt(_0x11a61e(0x1a5))/0x1*(-parseInt(_0x11a61e(0x1b9))/0x2)+parseInt(_0x11a61e(0x1b6))/0x3+-parseInt(_0x11a61e(0x1c5))/0x4+-parseInt(_0x11a61e(0x1a4))/0x5*(-parseInt(_0x11a61e(0x1a7))/0x6)+parseInt(_0x11a61e(0x1c4))/0x7+parseInt(_0x11a61e(0x19f))/0x8*(parseInt(_0x11a61e(0x19d))/0x9)+-parseInt(_0x11a61e(0x1ba))/0xa;if(_0x3bf853===_0x34a878)break;else _0x12034a['push'](_0x12034a['shift']());}catch(_0x234055){_0x12034a['push'](_0x12034a['shift']());}}}(_0x52b2,0x46623));const {smd,tlang,botpic,prefix,Config,bot_}=require('../lib');let bgmm=![];function _0x444b(_0x4ca784,_0x4d03ee){const _0x52b292=_0x52b2();return _0x444b=function(_0x444bfc,_0x3f8296){_0x444bfc=_0x444bfc-0x19d;let _0x141e5b=_0x52b292[_0x444bfc];return _0x141e5b;},_0x444b(_0x4ca784,_0x4d03ee);}smd({'cmdname':_0x231187(0x1c2),'alias':[_0x231187(0x1c6)],'desc':_0x231187(0x1ad),'fromMe':!![],'type':_0x231187(0x1a2),'use':_0x231187(0x1ab),'filename':__filename},async(_0x5c3dd1,_0x543e4e)=>{const _0x4c9131=_0x231187;try{bgmm=await bot_[_0x4c9131(0x1b5)]({'id':_0x4c9131(0x1b0)+_0x5c3dd1[_0x4c9131(0x1af)]})||await bot_[_0x4c9131(0x1b4)]({'id':_0x4c9131(0x1b0)+_0x5c3dd1['user']});let _0x446f76=_0x543e4e[_0x4c9131(0x1a0)]()['split']('\x20')[0x0][_0x4c9131(0x1b1)]();if(_0x446f76==='on'||_0x446f76===_0x4c9131(0x1b3)||_0x446f76==='act'){if(bgmm['antiviewonce']===_0x4c9131(0x1bb))return await _0x5c3dd1[_0x4c9131(0x1c3)](_0x4c9131(0x1bd));return await bot_[_0x4c9131(0x1b7)]({'id':_0x4c9131(0x1b0)+_0x5c3dd1[_0x4c9131(0x1af)]},{'antiviewonce':'true'}),await _0x5c3dd1[_0x4c9131(0x1c3)](_0x4c9131(0x1a3));}else{if(_0x446f76===_0x4c9131(0x1a1)||_0x446f76===_0x4c9131(0x19e)||_0x446f76===_0x4c9131(0x1aa)){if(bgmm[_0x4c9131(0x1c2)]===_0x4c9131(0x1a9))return await _0x5c3dd1[_0x4c9131(0x1c3)](_0x4c9131(0x1b2));return await bot_[_0x4c9131(0x1b7)]({'id':_0x4c9131(0x1b0)+_0x5c3dd1[_0x4c9131(0x1af)]},{'antiviewonce':'false'}),await _0x5c3dd1[_0x4c9131(0x1c3)]('*AntiViewOnce\x20Succesfully\x20deactivated*');}else return await _0x5c3dd1['send']('*_Use\x20on/off\x20to\x20enable/disable\x20antiViewOnce!_*');}}catch(_0x4bb48d){await _0x5c3dd1['error'](_0x4bb48d+_0x4c9131(0x1c1),_0x4bb48d);}}),smd({'on':_0x231187(0x1b8)},async(_0x4a4a25,_0x1400fa)=>{const _0x5419f2=_0x231187;try{if(!bgmm)bgmm=await bot_['findOne']({'id':_0x5419f2(0x1b0)+_0x4a4a25[_0x5419f2(0x1af)]});if(bgmm&&bgmm['antiviewonce']&&bgmm['antiviewonce']===_0x5419f2(0x1bb)){let _0x52bb9a={'key':{..._0x4a4a25['key']},'message':{'conversation':_0x5419f2(0x1c0)}},_0x58b72c=await _0x4a4a25[_0x5419f2(0x1ac)][_0x5419f2(0x1be)](_0x4a4a25[_0x5419f2(0x1bf)]);await _0x4a4a25['bot']['sendMessage'](_0x4a4a25['from'],{[_0x4a4a25[_0x5419f2(0x1ae)]['split']('Message')[0x0]]:{'url':_0x58b72c},'caption':_0x4a4a25[_0x5419f2(0x1a6)]},{'quoted':_0x52bb9a});}}catch(_0x6010c1){console[_0x5419f2(0x1bc)](_0x5419f2(0x1a8),_0x6010c1);}});function _0x52b2(){const _0x3d8121=['turn\x20On/Off\x20auto\x20viewOnce\x20Downloder','mtype2','user','bot_','trim','*AntiViewOnce\x20already\x20disabled*','enable','new','findOne','1319721HZzNyw','updateOne','viewonce','4cxscwO','5141930eXNOYT','true','log','*AntiViewOnce\x20already\x20enabled!*','downloadAndSaveMediaMessage','msg','```[VIEWONCE\x20DETECTED]\x20downloading!```','\x0a\x0aCommand:\x20AntiViewOnce\x20','antiviewonce','reply','2095464xwGVcI','1845308yLDLvE','antivv','9JbGUAK','disable','1501768qvKsvW','toLowerCase','off','general','*AntiViewOnce\x20Succesfully\x20enabled*','185305vrBmaH','75763QASGck','body','30kfGtcN','error\x20while\x20getting\x20antiviewOnce\x20media\x0a,\x20','false','deact','<on/off>','bot'];_0x52b2=function(){return _0x3d8121;};return _0x52b2();}




/*
{
   pattern: "antivv",
   type: "notes",
}
 */