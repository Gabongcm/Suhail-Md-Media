
/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail <https://github.com/SuhailTechInfo>
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.5 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 20/12/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/














const _0x9b7f14=_0x29a8;function _0x29a8(_0x5907cd,_0x661b1b){const _0x447193=_0x4471();return _0x29a8=function(_0x29a8ab,_0x15a348){_0x29a8ab=_0x29a8ab-0x11a;let _0x5c839e=_0x447193[_0x29a8ab];return _0x5c839e;},_0x29a8(_0x5907cd,_0x661b1b);}(function(_0x55bf91,_0x298060){const _0x3864a9=_0x29a8,_0x24f862=_0x55bf91();while(!![]){try{const _0x1ef52f=parseInt(_0x3864a9(0x129))/0x1+-parseInt(_0x3864a9(0x11c))/0x2+parseInt(_0x3864a9(0x126))/0x3*(-parseInt(_0x3864a9(0x131))/0x4)+-parseInt(_0x3864a9(0x12a))/0x5*(-parseInt(_0x3864a9(0x132))/0x6)+parseInt(_0x3864a9(0x11b))/0x7*(-parseInt(_0x3864a9(0x134))/0x8)+parseInt(_0x3864a9(0x136))/0x9*(parseInt(_0x3864a9(0x128))/0xa)+-parseInt(_0x3864a9(0x127))/0xb;if(_0x1ef52f===_0x298060)break;else _0x24f862['push'](_0x24f862['shift']());}catch(_0x550c1b){_0x24f862['push'](_0x24f862['shift']());}}}(_0x4471,0xa84a0));const {smd,tlang,prefix,Config,sleep,getBuffer,smdJson,smdBuffer}=require('../lib');function _0x4471(){const _0x379ec1=['delete\x20messages\x20of\x20user\x20from\x20chat','push','9Hpayhb','14999754EuLHYo','15310sAUirm','1354299vKuoDl','458940sDBPGn','loadMessages','delete','mentionedJid','quoted','length','*Please\x20reply/@user\x20to\x20delete\x20messages!*\x0a*Use\x20\x27','1129184EERQxN','84idrfTn','delspam','8AlKuqY','delete\x20messages\x20of\x20replied/@mentioned\x20user\x20from\x20chat\x20by\x20giving\x20number\x20of\x20messages!','7173xjgdmy','admin','log','3196067ajKqLk','1006286EUwSZR','send','split','includes','tech','group','dlspam','participant'];_0x4471=function(){return _0x379ec1;};return _0x4471();}async function loadMessages(_0x29790e,_0x550013,_0x11f938=''){const _0x4dd5b2=_0x29a8;try{_0x11f938=(_0x11f938?_0x11f938:_0x550013)[_0x4dd5b2(0x11e)]('@')[0x0];let _0x3edb4f=await _0x29790e[_0x4dd5b2(0x12b)](_0x550013),_0x438080=[];for(let _0x10cec1=0x0;_0x10cec1<_0x3edb4f[_0x4dd5b2(0x12f)];_0x10cec1++){_0x3edb4f[_0x10cec1]['key'][_0x4dd5b2(0x123)]?.[_0x4dd5b2(0x11f)](_0x11f938)&&_0x438080[_0x4dd5b2(0x125)](_0x3edb4f[_0x10cec1]);}return _0x438080;}catch(_0x5085fb){return console[_0x4dd5b2(0x11a)](_0x5085fb),[];}}smd({'pattern':_0x9b7f14(0x133),'alias':[_0x9b7f14(0x122)],'category':_0x9b7f14(0x120),'desc':_0x9b7f14(0x124),'use':'[\x204/\x206/\x2010\x20]','usage':_0x9b7f14(0x135),'filename':__filename},async(_0x4dc028,_0x422147,{store:_0x205c9c})=>{const _0x29e0b0=_0x9b7f14;try{if(!_0x4dc028['isGroup'])return await _0x4dc028[_0x29e0b0(0x11d)](tlang(_0x29e0b0(0x121)));if(!_0x4dc028['isBotAdmin'])return await _0x4dc028[_0x29e0b0(0x11d)]('I\x20am\x20Not\x20Admin!');if(!_0x4dc028['isAdmin']&&!_0x4dc028['isCreator'])return await _0x4dc028['send'](tlang(_0x29e0b0(0x137)));let _0x2505f5=_0x4dc028['quoted']?_0x4dc028[_0x29e0b0(0x12e)]['senderNum']:_0x4dc028[_0x29e0b0(0x12d)][0x0]?_0x4dc028['mentionedJid'][0x0]:![];if(!_0x2505f5)return await _0x4dc028['send'](_0x29e0b0(0x130)+prefix+'delspam\x205\x20@user\x27\x20(delete\x205\x20msgs)*');let _0x49d301=await loadMessages(_0x205c9c,_0x4dc028['chat'],_0x2505f5),_0x5b8854=parseInt(_0x422147[_0x29e0b0(0x11e)]('\x20')[0x0])||0x5,_0x4e3941=_0x49d301[_0x29e0b0(0x12f)]-_0x5b8854;for(let _0xdded2a=_0x49d301['length']-0x1;_0xdded2a>=_0x4e3941;_0xdded2a--){try{_0x49d301[_0xdded2a]&&await _0x4dc028[_0x29e0b0(0x12c)](_0x49d301[_0xdded2a]);}catch(_0x4bd6df){}}}catch(_0x490288){console[_0x29e0b0(0x11a)](_0x490288);}});




/*
{
   pattern: "delspam",
   type: "tools",
}
 */