/**

//══════════════════════════════════════════════════════════════════════════════════════════════════════//
//                                                                                                      //
//                                ＷＨＡＴＳＡＰＰ ＢＯＴ－ＭＤ ＢＥＴＡ                                   //
//                                                                                                      // 
//                                         Ｖ：1．2．2                                                   // 
//                                                                                                      // 
//            ███████╗██╗   ██╗██╗  ██╗ █████╗ ██╗██╗         ███╗   ███╗██████╗                        //
//            ██╔════╝██║   ██║██║  ██║██╔══██╗██║██║         ████╗ ████║██╔══██╗                       //
//            ███████╗██║   ██║███████║███████║██║██║         ██╔████╔██║██║  ██║                       //
//            ╚════██║██║   ██║██╔══██║██╔══██║██║██║         ██║╚██╔╝██║██║  ██║                       //
//            ███████║╚██████╔╝██║  ██║██║  ██║██║███████╗    ██║ ╚═╝ ██║██████╔╝                       //
//            ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚══════╝    ╚═╝     ╚═╝╚═════╝                        //
//                                                                                                      //
//                                                                                                      //
//                                                                                                      //
//══════════════════════════════════════════════════════════════════════════════════════════════════════//

CURRENTLY RUNNING ON BETA VERSION!!
*
   * @project_name : Suhail-Md
   * @author : Suhail <https://github.com/SuhailTechInfo>
   * @youtube : https://www.youtube.com/c/@SuhailTechInfo
   * @infoription : Suhail-Md ,A Multi-functional whatsapp user bot.
   * @version 1.2.6 
*
   * Licensed under the  GPL-3.0 License;
* 
   * ┌┤Created By Suhail Tech Info.
   * © 2023 Suhail-Md ✭ ⛥.
   * plugin date : 18/12/2023
* 
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   * SOFTWARE.
**/







const {
    smd,
    prefix, 
    Config ,
    sleep
     } = require('../lib')







smd({
    cmdname: "hack",    
    type: "fun",    
    info: "hacking prank",    
    filename: __filename,

},

async(citel) => {    
await citel.send("Injecting Malware")   
await sleep(2000)    
await citel.send(" █ 10%")    
await sleep(1000)    
await citel.send(" █ █ 20%")    
await sleep(1000)    
await citel.send(" █ █ █ 30%")    
await sleep(1000)    
await citel.send(" █ █ █ █ 40%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ 50%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ 60%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ 70%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ 80%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ █ 90%")    
await sleep(1000)    
await citel.send(" █ █ █ █ █ █ █ █ █ █ 100%")    
await sleep(1000)    
await citel.send("System hyjacking on process.. \n Conecting to Server error to find 404 ")    
await sleep(1000)    
await citel.send("Device successfully connected... \n Riciving data...")    
await sleep(1000)    
await citel.send("Data hyjacked from divice 100% completed \n killing all evidence killing all malwares...")
await sleep(1000)    
await citel.send(" HACKING COMPLETED ")    
await sleep(2000)    
await citel.send(" SENDING LOG DOCUMENTS...")    
await sleep(1000)
await citel.send(" SUCCESSFULLY SENT DATA AND Connection disconnected")    
await sleep(1000)

    return await citel.send('BACKLOGS CLEARED');

}

)